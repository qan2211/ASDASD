<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dtdm2";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$ID = $_POST['id'];
$Name = $_POST['name'];
$Class = $_POST['lop'];

$sql = "UPDATE danhsach SET `tensinhvien` = '$Name', `lop` = '$Class' Where `id` = '$ID'";

if ($conn->query($sql) === TRUE) {
    echo "Record updated successfully";
} else {
    echo "Error updating record: " . $conn->error;
}

$conn->close();
?>
<a href="index.php">Ve trang quan tri</a>