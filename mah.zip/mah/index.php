<?php 
 session_start();
 ob_start();
 mysql_connect("localhost","root","");
 mysql_select_db("dtdm2");
?>
<html>
    <head>
        <title></title>
    </head>
    <body>
        <h3>Danh sach sinh vien</h3>
        <table border='1'>
    <tr>
	<td>ID</td> 
    <td>Ten sinh vien</td>
	<td>Lop</td>

                   
    </tr>
        <?php
        $sql="SELECT `id`,`tensinhvien`,`lop` FROM danhsach";
        $query=  mysql_query($sql);
        while($row =  mysql_fetch_array($query)){
        ?>
    <tr>
	<td><?php echo $row['id'];?></td> 
    <td><?php echo $row['tensinhvien'];?></td>
	<td><?php echo $row['lop'];?></td>
    </tr>
        <?php } ?>
    </table>
    </body>
</html>

    </table>
        <form action="them.php" method="post">
            <h2> ID </h2><input type="text" name="id"></input>
            <h2> Ten </h2><input type="text" name="name"></input>
			<h2> Lop </h2><input type="text" name="lop"></input>
                  <input type="submit" name="ok" value="OK"></input>
        </form>
        
        <hr><br><a href="xoa.php">Xoa SV</a>
        <a href="sua.php">Sua thong tin sinh vien</a>
    </body>
</html>
