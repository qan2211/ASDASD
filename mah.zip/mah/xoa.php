
<?php 
 session_start();
 ob_start();
 mysql_connect("localhost","root","");
 mysql_select_db("dtdm2");
?>
<html>
    <head>
        <title></title>
    </head>
    <body>
        <h3>Danh sach sinh vien</h3>
        <table border='1'>
    <tr>
	<td>ID</td> 
        <td>Ten sinh vien</td>
		<td>Lop</td>

                   
    </tr>
        <?php
        $sql="SELECT `id`,`tensinhvien`,`lop` FROM danhsach";
        $query=  mysql_query($sql);
        while($row =  mysql_fetch_array($query)){
        ?>
    <tr>
	<td><?php echo $row['id'];?></td> 
        <td><?php echo $row['tensinhvien'];?></td>
		<td><?php echo $row['lop'];?></td>
    </tr>
        <?php } ?>
    </table>
    </body>
</html>
<html>
    <head>
        <title></title>
    </head>
    <body>
        <form action="xoasp.php" method="post">
            <h2> ID can xoa </h2><input type="text" name="id"></input>
            <input type="submit" name="xoa" value="xoa"></input>
        </form>
    </body>
</html>