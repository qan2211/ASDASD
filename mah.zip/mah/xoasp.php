<?php
$dsn="mysql:host=localhost;dbname=dtdm2";
$username="root";
$password="";

$db=new PDO($dsn,$username,$password);

if (isset( $_POST['id'])){
 $ma=$_POST['id'];
 $sql="delete from danhsach where id='$ma'";
 //echo $sql;
 $db->exec($sql);
echo 'Da xoa';

}
?>
<br><a href="index.php">Ve trang quan tri</a>