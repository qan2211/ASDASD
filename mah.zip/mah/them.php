<?php

$dsn='mysql:host=localhost;dbname=dtdm2';
$username='root';
$password='';
$db= new PDO($dsn, $username, $password);

$ID = $_POST['id'];
$Name = $_POST['name'];
$Class = $_POST['lop'];


$query = "INSERT INTO danhsach VALUES ('".$ID."','".$Name."','".$Class."')";
$result = $db->exec($query);
echo ' Đã thêm '. "$result" .'dòng vào cơ sở dữ liệu.';

?>
<a href="index.php">Ve trang chu</a>